<?php
/**
 * Template to display theme sidebar.
 *
 * @link https://thriveweb.com.au/the-lab/supesu-responsive-wordpress-5-theme/
 *
 * @package Supesu Theme
 * @version 1.0.6
 */

?>

<?php dynamic_sidebar( $index );
