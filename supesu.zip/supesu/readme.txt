Supesu is a WordPress theme we are releasing for free. It has been designed to be minimal, simply coded and easy to customise.

Features include:
- Optional theme customisation in the Theme Customiser.
- Responsive and browser friendly.
- Full width layout.
- Custom header, link and accent colours.
- Social media integration.

License:

- The Supesu theme and all of its bundles resources are used under GNU General Public License 3.0
- All Google fonts used in this theme are used under the SIL Open Font License 1.1
- Font Awesome icons are used under the Attribution 4.0 International (CC BY 4.0) License

See more at https://thriveweb.com.au/the-lab/supesu-responsive-wordpress-5-theme/
